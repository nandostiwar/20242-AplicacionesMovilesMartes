import '../styles/Resultado.css';

function Resultado({resultado}){
    return (
        <p>{resultado}</p>
    )
}

export default Resultado;